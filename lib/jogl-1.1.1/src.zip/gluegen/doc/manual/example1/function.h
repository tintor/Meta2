int one_plus(int a);
